<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'sitenl' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'root' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'MySQL-8.0' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '5k+9N|M0h}7uoD<ai:2AgiZD}bHZ*O/79x{xaJ%Ghn;#,},_-!Lh:%c#[JDrH-h2' );
define( 'SECURE_AUTH_KEY',  'T&$zUb#]S%9.R6=ctn}d{(kN[ioLJ#oW&=im!;C:DQ,T|UH]1X$%r1S]xnhn5_,?' );
define( 'LOGGED_IN_KEY',    ']H%zBExH*$%o|xj% _z*dzp^?2VHiD)G-1Z*(`nP%/b%A{`$-o?F+a/)V7ZC&RJq' );
define( 'NONCE_KEY',        ']`1NX)4oIXu_FE2<Yt>{Qsdr1oo,?7L4 NS93]AKflJpzp{hB.R#U]/-^P,D_,`q' );
define( 'AUTH_SALT',        '(CN1!J@k{G@kG/[nk0u?`S*+pmoX9hs*KaOJqVKq]&=BJV5v@zw51dN#-2-A}(<y' );
define( 'SECURE_AUTH_SALT', '5oGb6ktxdsP4>l~{!i$VuUFHR&V^x{,OYeY*lgC6LkoPP v*aWh`!,(`bc{ms-tl' );
define( 'LOGGED_IN_SALT',   'I`<=:k?y`+6sq3+OdoBsc5Wi;Mi-zQg &sg~xX={?>*J?3ksDp!DcYM/0.W[v?*-' );
define( 'NONCE_SALT',       '2%C$oJZZ-jis|CAtpW1~{M<bv,ev6Bs3D$&]d?x&7F6WAg1*u*480Qy]M1-DBr9S' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'nl_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
